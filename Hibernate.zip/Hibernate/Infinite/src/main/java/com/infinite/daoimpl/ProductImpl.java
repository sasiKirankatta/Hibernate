package com.infinite.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infinite.daohelper.DaoHelper;
import com.infinite.pojo.Product;

public class ProductImpl {
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;
	private Configuration con;
	private Transaction t;

	// private Session sessionObj;
	public void saveData(Product e) {
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		sessionObj.save(e);
		t.commit();

	}

	public void createRecord(Product e) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory

		try {
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product st = (Product) sessionObj.get(Product.class, e.getId());
			st.setProductName(st.getProductName());
			st.setPrice(st.getPrice());
			st.setQuantity(st.getQuantity());
			st.setSubTotal(st.getSubTotal());
			/*
			 * sessionObj.update(StudentName); sessionObj.update(RollNumber);
			 * sessionObj.update(Course);
			 */
			sessionObj.update(st);
			sessionObj.save(st);
			sessionObj.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}

	}

}