package com.infinite.controller;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.daoimpl.ProductImpl;

import com.infinite.pojo.Product;

//import com.mysql.cj.xdevapi.SessionFactory;

@Controller

public class InsertController {

	private ApplicationContext con;

	@RequestMapping(value = "/insert", method = RequestMethod.POST)

	public String insert(@ModelAttribute("bean") Product e, Model m) {

		con = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		ProductImpl obj = con.getBean("dao", ProductImpl.class);

		obj.saveData(e);

		String Product = e.getProductName();

		int Price = e.getPrice();

		int Quantity = e.getQuantity();

		int subtotal = e.getSubTotal();

		// Session sessionobj = sessionFactory;

		// m.addAttribute("msg",StudentName);

		System.out.println("i");

		return "inserted";

	}

}